#include <stdio.h>

int main() {

    int pooria = 4;

    printf("pooria is: %d\n", pooria);
    printf("address of pooria is: %d\n", &pooria);

}